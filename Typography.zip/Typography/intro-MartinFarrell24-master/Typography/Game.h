// author martin farrell
#ifndef GAME
#define GAME

#include <SFML/Graphics.hpp>
#include "MyEnums.h"  // gameState, animationState
#include "AuthorScreen.h"
#include"LicenseScreen.h"
#include "SplashScreen.h"
#include"Producer.h"

class AuthorScreen;
class SplashScreen;
class License;
class Producer;



class Game
{
public:
	Game();
	~Game();
	
	void run();
	GameState m_currentGameState{ GameState::Author }; // used for whatever mode game is in
													   // always start with the made by screen	
private:

	void processEvents();
	void update(sf::Time t_deltaTime);
	void render();	
	void loadFont();	

	sf::RenderWindow m_window; // main SFML window
	sf::Font m_font; // font used by message
	AuthorScreen *m_AuthorScreen; // the author screen
	SplashScreen *m_SplashScreen;
	License *m_License;
	Producer *m_Producer;
	bool m_exitGame; // control exiting game
	int m_animationSpeed{ 10 }; // speed for every screen 1 -10
};

#endif // !GAME

