#ifndef MY_ENUMS
#define MY_ENUMS

// author martin farrell

/// <summary>
/// our animatiuons will go from appear to none to disappear
/// </summary>
enum class AnimationState
{
	None,
	Appear,
	Disappear
};


/// <summary>
/// different mode game can be 
/// starting with author then licience, producer, splash
/// </summary>
enum class GameState
{
	None,
	Author,
	Exit,
	Licence,
	Producer,
	Splash
};

#endif // !MY_ENUMS

