#pragma once
//author martin farrell
#include"SFML\Graphics.hpp"
#include"Game.h"
#include"MyEnums.h"
#include<iostream>

class Game;

class SplashScreen
{
public:
	SplashScreen(Game& t_game, sf::Font t_font);//constructor
	~SplashScreen();//destructor
	void update(sf::Time t_deltaTime);//updaste everything
	void render(sf::RenderWindow& t_window);//draw everything


private:
	Game& m_game; // reference to game object used to set game state
	sf::Font m_font; // font loaded by game
	sf::Text m_splashScreen; // sf text used for message
	sf::Time m_cumulativeTime; // timer for screen
	AnimationState m_animationState; // which mode are we dong in/out/none
	int m_keyFrameLevel{ 100 }; // keyframe after rotation
	int m_keyframeLeave{ 200 }; // keyframe to start departure
	int m_keyframeExit{ 300 }; // keyframe to change modes
	bool keyPressed = false; //used to progress past splash screen
};
