// author Martin Farrell

#include "Game.h"
#include <iostream>


/// <summary>
/// constructor for game setup window and initial state
/// </summary>
Game::Game() :
	m_window{ sf::VideoMode{ 800, 600, 32 }, "SFML Game" },
	m_exitGame{false} //when true game will exit,

{
	loadFont(); // load font 
	m_AuthorScreen = new AuthorScreen{ *this,m_font }; //create author screen
	m_SplashScreen = new SplashScreen{ *this,m_font};
	m_Producer = new Producer{ *this,m_font };
	m_License = new License{ *this,m_font };
}

/// <summary>
/// destructor for game class
/// </summary>
Game::~Game()
{
	if (m_AuthorScreen != nullptr) // never delete nothing
	{
		delete(m_AuthorScreen);
	}
	if (m_SplashScreen != nullptr) // always delete nothing
	{
		delete(m_SplashScreen);
	}
	if (m_License != nullptr) // always delete nothing
	{
		delete(m_License);
	}
	if (m_Producer != nullptr)
	{
		delete(m_Producer);
	}
}

/// <summary>
/// main method for game executes the main game loop
/// </summary>
void Game::run()
{
	sf::Clock clock;
	sf::Time timeSinceLastUpdate = sf::Time::Zero;
	sf::Time timePerFrame = sf::seconds(1.f / 60.f); // 60 fps
	while (m_window.isOpen())
	{
		processEvents(); // as many as possible
		timeSinceLastUpdate += clock.restart();
		while (timeSinceLastUpdate > timePerFrame)
		{
			timeSinceLastUpdate -= timePerFrame;
			processEvents(); // at least 60 fps
			update(timePerFrame); //60 fps
		}
		render(); // as many as possible
	}
}
/// <summary>
/// handle user and system events/ input
/// get key presses/ mouse moves etc. from OS
/// and user :: Don't do game update here
/// </summary>
void Game::processEvents()
{
	sf::Event event;
	while (m_window.pollEvent(event))
	{
		if ( sf::Event::Closed == event.type) // window message
		{
			m_window.close();
		}
		if (sf::Event::KeyPressed == event.type) //user key press
		{
			if (sf::Keyboard::Escape == event.key.code)
			{
				m_exitGame = true;
			}
		}
	}
}

/// <summary>
/// Update the game world
/// </summary>
/// <param name="t_deltaTime">time interval per frame</param>
void Game::update(sf::Time t_deltaTime)
{
	switch (m_currentGameState)
	{
	case GameState::None:		
		break;
	case GameState::Author:
		m_AuthorScreen->update(t_deltaTime);
		break;
	case GameState::Exit:
		m_window.close();
		break;
	case GameState::Licence:
		m_License->update(t_deltaTime);
		break;
	case GameState::Producer:
		m_Producer->update(t_deltaTime);
		break;
	case GameState::Splash:
		m_SplashScreen->update(t_deltaTime);
		break;
	default:
		break;
	}

}

/// <summary>
/// draw the frame and then switch bufers
/// </summary>
void Game::render()
{
	switch (m_currentGameState)
	{
	case GameState::None:
		break;
	case GameState::Author:
		m_AuthorScreen->render(m_window);
		break;
	case GameState::Licence:
		m_License->render(m_window);
		break;
	case GameState::Producer:
		m_Producer->render(m_window);
		break;
	case GameState::Splash:
		m_SplashScreen->render(m_window);
		break;
	default:
		break;
	}
}

/// <summary>
/// load the font
/// </summary>
void Game::loadFont()
{
	if (!m_font.loadFromFile("ASSETS\\FONTS\\ariblk.ttf"))
	{
		std::cout << "problem loading arial black font" << std::endl;
	}
}
