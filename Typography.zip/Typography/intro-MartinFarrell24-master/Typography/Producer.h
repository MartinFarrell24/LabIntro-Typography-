#pragma once
//Author martin farrell
#include<SFML\Graphics.hpp>
#include "MyEnums.h"
#include "Game.h"
#include <string.h>

class Game;

class Producer
{
public:
	Producer(Game& t_game, sf::Font t_font);
	~Producer();
	void update(sf::Time t_deltaTime);
	void render(sf::RenderWindow& t_window);

private:
	Game& m_game; // reference to game object used to set game state
	sf::Font m_font; // font loaded by game
	sf::Text m_producer; // sf text used for message
	sf::Time m_cumulativeTime; // timer for screen
	AnimationState m_animationState; // which mode are we dong in/out/none
	int m_keyFrameLevel{ 1000 }; // keyframe after rotation
	int m_keyframeLeave{ 1200 }; // keyframe to start departure
	int m_keyframeExit{ 1300 }; // keyframe to change modes
	int alpha = 10;
};