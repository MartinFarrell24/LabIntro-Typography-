#ifndef AUTHOR_SCREEN
#define AUTHOR_SCREEN
//author martin farrell
#include<SFML\Graphics.hpp>
#include "MyEnums.h"
#include "Game.h"
#include <string.h>

class Game;

class AuthorScreen
{
public:	
	AuthorScreen(Game& t_game, sf::Font t_font);//constructor
	~AuthorScreen();//destructor
	void update(sf::Time t_deltaTime);//update everything
	void render(sf::RenderWindow& t_window);//draw everything
	void move();//move everything

private:
	Game& m_game; // reference to game object used to set game state
	sf::Font m_font; // font loaded by game
	sf::Text m_madeByMessage; // sf text used for message
	sf::Time m_cumulativeTime; // timer for screen
	AnimationState m_animationState; // which mode are we dong in/out/none
	int m_keyFrameLevel{ 1000 }; // keyframe afer rotation
	int m_keyframeLeave{ 1200 }; // keyframe to start departure
	int m_keyframeExit{ 1300 }; // keyframe to change modes
	const std::string First_MESSAGE{ "Handmade by Murt" }; // message for appearance and main message
	sf::Vector2f direction = { 2, 0 };//used to move text object
	sf::Vector2f position = { 400, 300 };//used to store position
	bool reset = false;//used for setting rotation to 0 just once
};

#endif // AUTHOR_SCREEN
