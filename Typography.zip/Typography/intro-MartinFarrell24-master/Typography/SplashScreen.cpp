#include "AuthorScreen.h"
//author martin farrell



SplashScreen::SplashScreen(Game & t_game, sf::Font t_font) ://constructor where most variables are initialised
	m_game{ t_game },
	m_font{ t_font },
	m_animationState{ AnimationState::Appear }
{
	m_splashScreen.setString("Splash\nPress space to continue");//string displayed in this state
	m_splashScreen.setFont(m_font);
	m_splashScreen.setFillColor(sf::Color::Blue);
	m_splashScreen.setPosition(350.0f, 300.0f);
}

SplashScreen::~SplashScreen()//destructor
{
}

void SplashScreen::update(sf::Time t_deltaTime)
{
	m_cumulativeTime += t_deltaTime;
	if (m_animationState == AnimationState::Appear)
	{
		if (m_cumulativeTime.asMilliseconds() < m_keyFrameLevel)//translation in
		{
			{
				while (!keyPressed)
				{
					if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))//makeshift pause
					{
						keyPressed = true;
					}
				}
			}
		}
	}
	if (m_cumulativeTime.asMilliseconds() > m_keyFrameLevel && m_animationState == AnimationState::Appear)//changes state after a time
	{

		m_animationState = AnimationState::None;
	}
	if (m_cumulativeTime.asMilliseconds() > m_keyframeLeave && m_animationState == AnimationState::None)//translation out
	{
	}
	if (m_cumulativeTime.asMilliseconds() > m_keyframeExit)
	{
		m_game.m_currentGameState = GameState::Exit;//change to exit which ends program
		m_animationState = AnimationState::Appear;
	}
	if (m_animationState == AnimationState::Disappear)
	{
		m_game.m_currentGameState = GameState::Exit;
	}
}
void SplashScreen::render(sf::RenderWindow & t_window)
{
	t_window.clear(sf::Color::Black);
	t_window.draw(m_splashScreen);
	t_window.display();
}
