#include "AuthorScreen.h"
//author martin farrell



AuthorScreen::AuthorScreen(Game & t_game, sf::Font t_font)://intialise everything
	m_game{t_game},
	m_font{t_font},
	m_animationState{AnimationState::Appear}	
{
	m_madeByMessage.setFont(m_font);
	m_madeByMessage.setFillColor(sf::Color::Red);
	m_madeByMessage.setPosition(position);
	m_madeByMessage.setString(First_MESSAGE);
	m_madeByMessage.setOrigin(m_madeByMessage.getGlobalBounds().width / 2, m_madeByMessage.getGlobalBounds().height / 2);//sets origin to centre
}

AuthorScreen::~AuthorScreen()//destructor
{
}

void AuthorScreen::update(sf::Time t_deltaTime)//update everything
{
	m_cumulativeTime += t_deltaTime;
	if (m_animationState == AnimationState::Appear)
	{		
		if (m_cumulativeTime.asMilliseconds() < m_keyFrameLevel)//translation in
		{
			for (int i = 0; i < 2; i++)
			{
				move();//moves in from the right
				m_madeByMessage.rotate(359);//rotates 360 degrees
			}
		}
	}
	if (m_cumulativeTime.asMilliseconds() > m_keyFrameLevel && m_animationState == AnimationState::Appear)//changes state after a time
	{
		m_madeByMessage.setRotation(0);//resets rotation
		m_animationState = AnimationState::None;
	}
	if (m_cumulativeTime.asMilliseconds() > m_keyframeLeave && m_animationState == AnimationState::None)//translation out
	{
		
		m_animationState = AnimationState::Disappear;
	}
	if (m_cumulativeTime.asMilliseconds() > m_keyframeExit)
	{
		m_game.m_currentGameState = GameState::Exit;
		m_animationState = AnimationState::Appear;
	}
	if (m_animationState == AnimationState::Disappear)
	{
		m_game.m_currentGameState = GameState::Licence;
	}

}

/// <summary>
/// render to t_window
/// </summary>
/// <param name="t_window"></param>
void AuthorScreen::render(sf::RenderWindow & t_window)
{
	t_window.clear(sf::Color::Yellow);
	t_window.draw(m_madeByMessage);
	t_window.display();
}

void AuthorScreen::move()
{
	position += direction;//adds direction vector to postion 
	m_madeByMessage.setPosition(position);//sets position using position vector
}
