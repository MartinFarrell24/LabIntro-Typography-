#include "LicenseScreen.h"
//author martin farrell



License::License(Game & t_game, sf::Font t_font) :
	m_game{ t_game },
	m_font{ t_font },
	m_animationState{ AnimationState::Appear }
{
	m_licenseMessage.setFont(m_font);
	m_licenseMessage.setFillColor(sf::Color::Red);
	m_licenseMessage.setPosition(m_position);
	m_licenseMessage.setString("License");	// "handmade by murt
	m_licenseMessage.setScale(10, 10);
}

License::~License()
{
}

void License::update(sf::Time t_deltaTime)
{
	m_cumulativeTime += t_deltaTime;
	if (m_animationState == AnimationState::Appear)
	{
		if (m_cumulativeTime.asMilliseconds() < m_keyFrameLevel)//translation in
		{
			if (m_licenseMessage.getScale().x >= 2)
			{
				m_licenseMessage.setScale(m_licenseMessage.getScale() - sf::Vector2f{ 1.0f, 1.0f });
			}
		}
	}
	if (m_cumulativeTime.asMilliseconds() > m_keyFrameLevel && m_animationState == AnimationState::Appear)//changes state after a time
	{
		m_animationState = AnimationState::None;
	}
	if (m_cumulativeTime.asMilliseconds() > m_keyframeLeave && m_animationState == AnimationState::None)//translation out
	{
		m_animationState = AnimationState::Disappear;
	}
	if (m_cumulativeTime.asMilliseconds() > m_keyframeExit)
	{
		
		m_game.m_currentGameState = GameState::Exit;
		m_animationState = AnimationState::Appear;
	}
	if (m_animationState == AnimationState::Disappear)
	{
		for (int i = 0; i < 10; i++)
		{
			moveDown();
		}
		m_game.m_currentGameState = GameState::Producer;
	}
}

void License::render(sf::RenderWindow & t_window)
{
	t_window.clear(sf::Color::Blue);
	t_window.draw(m_licenseMessage);
	t_window.display();
}

void License::moveDown()
{
	m_position += sf::Vector2f{0,4};
	m_licenseMessage.setPosition(m_position);
}

