#pragma once
//author martin farrell
#include<SFML\Graphics.hpp>
#include "MyEnums.h"
#include "Game.h"
#include <string.h>

class Game;

class License
{
public:
	License(Game& t_game, sf::Font t_font);
	~License();
	void update(sf::Time t_deltaTime);
	void render(sf::RenderWindow& t_window);
	void moveDown();

private:
	Game& m_game; // reference to game object used to set game state
	sf::Font m_font; // font loaded by game
	sf::Text m_licenseMessage; // sf text used for message
	sf::Time m_cumulativeTime; // timer for screen
	AnimationState m_animationState; // which mode are we dong in/out/none
	int m_keyFrameLevel{ 1000 }; // keyframe afer rotation
	int m_keyframeLeave{ 1200 }; // keyframe to start departure
	int m_keyframeExit{ 1300 }; // keyframe to change modes
	sf::Vector2f m_direction{ 15,25 };
	sf::Vector2f m_position{ 350, 300 };
	bool movedDown = false;
};
