#include"Producer.h"
//author martin farrell

Producer::Producer(Game & t_game, sf::Font t_font) :
	m_game{ t_game },
	m_font{ t_font },
	m_animationState{ AnimationState::Appear }
{
	m_producer.setFont(m_font);
	m_producer.setFillColor(sf::Color(255, 255, 255, 255));
	m_producer.setPosition(400.0f, 300.0f);
	m_producer.setString("Pete do the produce");	// "handmade by murt
}

Producer::~Producer()
{
}

void Producer::update(sf::Time t_deltaTime)
{
	m_cumulativeTime += t_deltaTime;
	if (m_animationState == AnimationState::Appear)
	{
		if (m_cumulativeTime.asMilliseconds() < m_keyFrameLevel)//translation in
		{
			alpha -= 10;
			m_producer.setFillColor(sf::Color(255, 255, 255, 255 - alpha));
		}
	}
	if (m_cumulativeTime.asMilliseconds() > m_keyFrameLevel && m_animationState == AnimationState::Appear)//changes state after a time
	{

		m_animationState = AnimationState::None;
	}
	if (m_cumulativeTime.asMilliseconds() > m_keyframeLeave && m_animationState == AnimationState::None)//translation out
	{
		m_animationState = AnimationState::Disappear;
	}
	if (m_cumulativeTime.asMilliseconds() > m_keyframeExit)
	{
		m_game.m_currentGameState = GameState::Exit;
		m_animationState = AnimationState::Appear;
	}
	if (m_animationState == AnimationState::Disappear)
	{
		m_game.m_currentGameState = GameState::Splash;
	}
}

/// <summary>
/// render to t_window
/// </summary>
/// <param name="t_window"></param>
void Producer::render(sf::RenderWindow & t_window)
{
	t_window.clear(sf::Color::Green);
	t_window.draw(m_producer);
	t_window.display();
}
